package Personagens;

public interface PersonagensStats {

    public int getHealth();
    public String getName();
    public int getStrength();
    public int getDamage();
    public int getDefense();
    public int getAgility();
    public void setHealth(int vida);
}
